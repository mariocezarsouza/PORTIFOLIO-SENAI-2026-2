"""API REST (bônus do TP3): expõe a base Model-Ready da Estante Virtual em JSON.

Execução, dentro desta pasta:
    uvicorn api_dados:app --port 8000

Endpoints:
    GET /                     resumo da API
    GET /dados                todos os registros
    GET /dados?limit=5&offset=10&faixa_preco=Caro&tema=Direito   paginação e filtros
    GET /docs                 documentação interativa gerada pelo FastAPI
"""
from functools import lru_cache
from pathlib import Path
from typing import Literal, Optional

import pandas as pd
from fastapi import FastAPI, Query

ARQUIVO_DADOS = Path(__file__).resolve().parent / "dados_modelo_pronto.csv"

app = FastAPI(
    title="Automated Web Crawler & ML-Ready Data Preparation Hub",
    description="Livros da Estante Virtual, higienizados e prontos para modelagem.",
    version="1.0.0",
)


@lru_cache(maxsize=1)
def carregar_dados() -> pd.DataFrame:
    """Lê o CSV uma única vez e mantém a base em memória."""
    return pd.read_csv(ARQUIVO_DADOS)


def para_registros(df: pd.DataFrame) -> list[dict]:
    """Converte para dicionários, trocando NaN por null (NaN não é JSON válido)."""
    return df.astype(object).where(df.notna(), None).to_dict(orient="records")


@app.get("/")
def raiz() -> dict:
    df = carregar_dados()
    return {
        "projeto": app.title,
        "registros": len(df),
        "colunas": list(df.columns),
        "endpoint": "/dados",
    }


@app.get("/dados")
def listar_dados(
    limit: Optional[int] = Query(None, ge=1, description="Máximo de registros retornados"),
    offset: int = Query(0, ge=0, description="Registros a pular"),
    faixa_preco: Optional[Literal["Barato", "Médio", "Caro"]] = Query(
        None, description="Filtra pela faixa de preço"
    ),
    tema: Optional[str] = Query(None, description="Filtra pelo tema da busca, por exemplo Direito"),
) -> dict:
    df = carregar_dados()
    if faixa_preco is not None:
        df = df[df["faixa_preco"] == faixa_preco]
    if tema is not None:
        df = df[df["tema_busca"] == tema]
    total = len(df)
    fim = None if limit is None else offset + limit
    pagina = df.iloc[offset:fim]
    return {
        "total_registros": total,
        "retornados": len(pagina),
        "offset": offset,
        "dados": para_registros(pagina),
    }
