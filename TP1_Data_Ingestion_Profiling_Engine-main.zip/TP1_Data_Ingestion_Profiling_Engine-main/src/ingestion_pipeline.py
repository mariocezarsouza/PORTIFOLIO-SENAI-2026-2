# Fase 1: Preparação do Banco de Dados Local (SQLite)

import pandas as pd
import sqlite3
import json
import numpy as np

conn = sqlite3.connect('varejo.db')
print("Banco de dados 'varejo.db' criado com sucesso!")
print()

cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS tb_vendas_consolidada (
    id_transacao TEXT PRIMARY KEY,
    data_venda TEXT,
    id_produto TEXT,
    quantidade INTEGER,
    valor_unitario REAL,
    canal_venda TEXT
);
''')

conn.commit()
print("Tabela 'tb_vendas_consolidada' criada com sucesso!")
print()


# Fase 2: O Pipeline de Extração, Transformação e Carga (ETL em Python)

# 2.1 Extração (Extract)

# Carregar o arquivo JSON
df_web = pd.read_json('data/vendas_web.json')

# print(df_web.head()) #Exibir as primeiras 5 linhas

# Carregar o arquivo CSV
df_lojas = pd.read_csv('data/vendas_lojas.csv')

# print(df_lojas.head()) #Exibir as primeiras 5 linhas


# 2.2 Transformação (Transform)

# Identificar a origem de cada dataset
df_web['canal_venda'] = 'E-commerce'
df_lojas['canal_venda'] = 'Loja Física'


# Renomear as colunas usando um dicionário e o método .rename()
df_web_padrao = df_web.rename(columns={
    "cod_transacao": "id_transacao",
    "data_registro": "data_venda",
    "id_prod": "id_produto",
    "quant": "quantidade",
    "preco_unitario": "valor_unitario",
})

df_lojas_padrao = df_lojas.rename(columns={
    "ID_Venda": "id_transacao",
    "Data": "data_venda",
    "Produto_ID": "id_produto",
    "Qtd": "quantidade",
    "Valor_Unit": "valor_unitario",
})

# print(df_web_padrao.head()) #Exibir as primeiras 5 linhas
# print(df_lojas_padrao.head()) #Exibir as primeiras 5 linhas

# Unificar os dois DataFrames
df_unificado = pd.concat([df_web_padrao, df_lojas_padrao], ignore_index=True)

# print(df_unificado.head(20)) #Exibir as primeiras 20 linhas


# Limpeza de Dados

# Filtrar quantidades positivas (> 0)
df_unificado = df_unificado[df_unificado['quantidade'] > 0].copy()

# Remover linhas onde valor unitario ou id_transacao sejam nulos ou vazios
df_unificado = df_unificado.dropna(subset=['valor_unitario', 'id_transacao'])

# print(df_unificado.head(20)) #Exibir as primeiras 20 linhas


# Normalização Temporal

# Converter a coluna para o tipo datetime de forma flexível
df_unificado['data_venda'] = pd.to_datetime(
    df_unificado['data_venda'],
    format='mixed',        # Identifica múltiplos formatos automaticamente
    dayfirst=True,         # Prioriza dia antes do mês em formatos ambíguos (05/04/2024 -> 05 de abril)
    errors='coerce'        # Converte valores corrompidos/inválidos em NaT (nulos)
)

# Converter para texto no formato padrão (YYYY-MM-DD)
df_unificado['data_venda'] = df_unificado['data_venda'].dt.strftime('%Y-%m-%d')

print(df_unificado.head(20)) #Exibir as primeiras 20 linhas


# 2.3 Carga (Load)

# Conectar ao banco de dados
conn = sqlite3.connect('varejo.db')

# Remove os IDs duplicados mantendo a primeira ocorrência
df_unificado = df_unificado.drop_duplicates(subset=['id_transacao'], keep='first')

# Limpa os dados da tabela antes da nova carga
cursor = conn.cursor()
cursor.execute('DELETE FROM tb_vendas_consolidada;')
conn.commit()

# Gravar os dados na tabela existente
df_unificado.to_sql(
    name='tb_vendas_consolidada',   # Nome da tabela no SQLite
    con=conn,                       # Conexão ativa
    if_exists='append',             # Insere os dados sem recriar a tabela
    index=False                     # Não salva o índice numérico do DataFrame como coluna
)

print()
print("Carga efetuada com sucesso!")

# Fechar a conexão
conn.close()
