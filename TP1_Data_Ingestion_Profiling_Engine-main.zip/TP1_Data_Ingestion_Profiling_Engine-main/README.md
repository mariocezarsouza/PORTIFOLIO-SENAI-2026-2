### TP1 - Data Ingestion & Profiling Engine
Pipeline de ingestão e análise de vendas

Pipeline automatizado (ETL) de carga, limpeza e integração de dados transacionais omnicanais (E-commerce e Loja Física) utilizando Python, SQLite, Pandas, Seaborn e Matplotlib.

*Alunos:* **Mário Cezar e Wellington Luzzi**

Estrutura do repositório:

```text
├── data/
│   ├── vendas_web.json              # Arquivo de entrada bruto (E-commerce)
│   ├── vendas_lojas.csv             # Arquivo de entrada bruto (Lojas Físicas)
│   └── vendas_ecommerce_limpo.json  # Arquivo de saída gerado (Exportação)
├── src/
│   └── ingestion_pipeline.py        # Script de ETL em Python (SQLite + Pandas)
├── notebooks/
│   └── analise_vendas.ipynb         # Relatório exploratório e gráfico de Profiling
├── varejo.db                        # Arquivo do banco de dados SQLite local
├── histograma_vendas.png            # Imagem do histograma gerado pelo Seaborn
└── README.md                        # Documentação e instruções de execução
```
Dependências e Ambiente

O projeto foi desenvolvido em Python 3.10+. Para instalar as bibliotecas necessárias, execute no terminal:

```
python -m pip install pandas seaborn matplotlib ipykernel
```

Instruções de Execução

**1. Clonar o repositório**
```
git clone https://github.com/WellingtonLuzzi/TP1_Data_Ingestion_Profiling_Engine.git
cd TP1_Data_Ingestion_Profiling_Engine
```

**2. Executar o pipeline de ingestão**

- Fase 1 - Preparação do Banco de Dados Local (SQLite) 
- Fase 2 - O Pipeline de Extração, Transformação e Carga (ETL em Python)
```
python src/ingestion_pipeline.py
```

Operações executadas:

- Criação da tabela DDL com restrição de chave primária (id_transacao).
- Ingestão dos arquivos data/vendas_web.json e data/vendas_lojas.csv.
- Padronização de schemas e tratamento de nulos/vazios.
- Remoção de registros com quantidade menores ou iguais a zero.
- Normalização temporal para o formato YYYY-MM-DD.
- Carga limpa na tabela do banco SQLite.

**3. Executar a Fase 3 - Notebook de análise e profiling**
```
jupyter notebook notebooks/analise_vendas.ipynb
```

Saídas geradas:

- Exportação filtrada para data/vendas_ecommerce_limpo.json (apenas transações do E-commerce).
- Exibição das métricas consolidadas: faturamento total, média de preço unitário e faturamento segmentado por canal.
- Geração e salvamento do gráfico histograma_vendas.png na raiz do projeto via Seaborn.


### ***Tecnologias utilizadas:***

**Linguagem:** Python

**Banco de Dados:** SQLite3

**Manipulação de Dados:** Pandas / NumPy

**Visualização de Dados:** Seaborn / Matplotlib
